# Saphyra-DDoS
A complex python code to DDoS any website with a very easy usage.



# Tested On :- 
  > Kali Linux
  
  > Parrot Sec OS 



# Steps to Install :- 

    $ sudo su

    $ git clone https://github.com/anonymous24x7/Saphyra-DDoS.git

    $ cd Saphyra-DDoS

    $ chmod +x saphyra.py

    $ python saphyra.py



# If it doesn't work :

Try

     $ sudo apt install python python2 python3

     $sudo apt update

     $sudo apt upgrade



# Usage :

    $ python saphyra.py https://example.com



# Disclaimer :

Please use this code at your own risk and NEVER TRY IT ON A WEBSITE YOU DON'T HAVE PERMISSION FROM 

I REPEAT NEVER.



# Wish me LUCK💵
https://www.buymeacoffee.com/anonymous24x7


https://imjo.in/QzaYw6    --INR Payments ONLY


🖤🖤🖤
